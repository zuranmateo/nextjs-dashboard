export default function Page() {
  return (
    <p>customers page</p>
  );
}